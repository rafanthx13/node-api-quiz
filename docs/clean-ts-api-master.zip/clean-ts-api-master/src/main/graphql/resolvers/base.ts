import { GraphQLDateTime } from 'graphql-iso-date'

export default {
  DateTime: GraphQLDateTime
}

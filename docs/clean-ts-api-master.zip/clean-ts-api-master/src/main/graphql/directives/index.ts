import { AuthDirective } from './auth-directive'

export default {
  auth: AuthDirective
}

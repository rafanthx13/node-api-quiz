export const notFound = {
  description: 'API não encontrada'
}

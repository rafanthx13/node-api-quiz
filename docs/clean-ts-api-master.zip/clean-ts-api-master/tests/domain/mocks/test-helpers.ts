export const throwError = (): never => {
  throw new Error()
}

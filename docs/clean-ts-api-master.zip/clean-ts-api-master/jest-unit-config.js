const config = require('./jest.config')
config.testMatch = ['**/*.spec.ts']
module.exports = config
